from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open('model.pkl', 'wb'))

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        gender = request.form['gender']
        Married = request.form['Married']
        Dependents = request.form['Dependents']
        Education = request.form['Education']
        Employed = request.form['Employed']
        AplInc = request.form['AplInc']
        CoAplInc = request.form['CoAplInc']
        LoanAmount = request.form['LoanAmount']
        credit = request.form['credit']
        area = request.form['area']
        
        #gender
        if(gender == "Male"):
           male=1
        else:
           male=0
        
        #married
        if(Married == "Yes"):
           Married_yes=1
        else:
           Married_no=0 
        
        #dependents
        if(Dependents == '1'):
           Dependents_1 = 1
           Dependents_2 = 0
           Dependents_3 = 0
           Dependents_4 = 0
        elif(Dependents == '2'):
           Dependents_1 = 0
           Dependents_2 = 1
           Dependents_3 = 0
           Dependents_4 = 0
        elif(Dependents == '3'):
           Dependents_1 = 0
           Dependents_2 = 0
           Dependents_3 = 1
           Dependents_4 = 0
        elif(Dependents == '3+'):
           Dependents_1 = 0
           Dependents_2 = 0
           Dependents_3 = 0
           Dependents_4 = 1
        else:
           Dependents_1 = 0
           Dependents_2 = 0
           Dependents_3 = 0
           Dependents_4 = 0         
        
        #Education
        if(Education == "Graduated"):
           Graduated=1
        else:
           Graduated=0

        #Employed
        if(Employed == "Yes"):
           Employed_yes=1
        else:
           Employed_yes=0
        
        #Area
        if(area == "Urban"):
           Urban=1
           Semiurban=0
           Rural=0
        elif(area == "Semi-urban"):
           Urban=0
           Semiurban=1
           Rural=0
        elif(area == "Rural"):
           Urban=0
           Semiurban=0
           Rural=1
        else:
           Urban=0
           Semiurban=0
           Rural=0    

        AplInc = np.log(AplInc)  
        CoAplInc = np.log(CoAplInc) 

        predict = model.predict([[ gender, Married, Dependents, Education, Employed, AplInc, CoAplInc, LoanAmount, credit, area]])

        if(predict=='N'):
           predict="No"
        else:
           predict="Yes"   

    else:
         return render_template("predict.html",predict_text="loan status is{}".format(predict))



if __name__=="__main__":
    app.run(debug=True)